$(document).ready(function(){

	// animation class addition starts//
	$('.home-banner-part__logo-body').addClass('banner-logo--animation-active')
	// animation class addition ends//



    // Home search starts
    var $input = $('#search_product');
    // Home search ends

    // Product list sort scripts starts
    $('.hex_product_list__custom-option').click(function(e){
		e.stopPropagation();
        var sortData = $(this).attr("data-value");
		var sortDataName = $(this).attr("data-name");
        $('#sortpost').val(sortData).trigger('change');
        $('.hex_product_list__select__trigger span').text(sortDataName);
        $('.hex_product_list__custom-option').removeClass('hex_product_list__right_filter_block__custom-option--selected');
        $(this).addClass('hex_product_list__right_filter_block__custom-option--selected');
		$('.hex_product_list__select').removeClass('hex_product_list__select--active');
    });
    $('.hex_product_list__select__trigger').click(function(e){
		e.stopPropagation()
        $(this).parent().addClass('hex_product_list__select--active');
    });
	
    // Product list sort scripts ends
   checkListView();

   //integration and devices page tab header script starts//
  
	// (()=>{  
	
		function mainController() {
			let getControllWrapper= document.querySelectorAll(".mhex_multi_tab_content_wrapper");
			getControllWrapper.forEach((val,index)=>{
				if(val.classList.contains("tab-active")) {
					return
				}
				val.classList.add('tab-active')
				let createLine = document.createElement("div"); 
				createLine.classList.add('line');
				val.querySelector(".mhex_multi_tab_header_nav").appendChild(createLine);
				let getActiveTabIndex= val.querySelector('.mhex_tab_nav_li.active');
				setActiveTab(val,getActiveTabIndex.getAttribute('data-index'));
				setActiveTabEventAdd(val);
			});
		}
	
	
		function setActiveTabEventAdd(passEle) {
			let getHeaderLi= passEle.querySelectorAll(".mhex_tab_nav_li");
			let getFooterLi= passEle.querySelectorAll(".mhex_muliti_tab_footer_nav ul li a");
	
			getHeaderLi.forEach((val,index)=>{
				if(val.addEventListener) {
					val.addEventListener('click',(e)=>{
						e.preventDefault();
						e.stopPropagation();
						setTabData(e,val,passEle,'header-nav');
						// locoScroll.update();

					},false);
				}else {
					val.attachEvent('onclick',(e)=>{
						e.preventDefault();
						e.stopPropagation();
						setTabData(e,val,passEle,'header-nav');
						// locoScroll.update();
					});
				}
			});
			if(getFooterLi) {
				getFooterLi.forEach((val,index)=>{
					if(val.addEventListener) {
						val.addEventListener('click',(e)=>{
							e.preventDefault();
							e.stopPropagation();
							setFooterTabData(e,val,passEle);
							// locoScroll.update();
						},false);
					}else {
						val.attachEvent('onclick',(e)=>{
							e.preventDefault();
							e.stopPropagation();
							setFooterTabData(e,val,passEle);
							// locoScroll.update();
						});
					}
				});
			}
		}
	
		function setTabData(e,val,passEle,type) {
			let setType= "";
			if(type == 'header-nav') {
				setType= ".mhex_tab_nav_li.active";
	
			}else {
				setType=".mhex_muliti_tab_footer_nav ul li.active"
			}
	
			let getActiveTab= passEle.querySelector(setType);
			let getId= val.querySelector('a').getAttribute('href');
			if(getActiveTab.querySelector('a').getAttribute('href') == `${getId}`) {
				return;
			}
			let getOldTabIndex= getActiveTab.getAttribute("data-index");
			getActiveTab.classList.remove('active');
			e.target.parentElement.classList.add('active');
			if(type == 'header-nav') {
				let getFooterActiveTab= passEle.querySelector(".mhex_muliti_tab_footer_nav ul li.active");
				(_getFooterActiveTab = getFooterActiveTab) === null || _getFooterActiveTab === void 0 ? void 0 : _getFooterActiveTab.classList.remove('active');
				let getNewIndex= passEle.querySelector(".mhex_tab_nav_li.active").getAttribute("data-index");
				(_passEle$querySelecto = passEle.querySelectorAll(".mhex_muliti_tab_footer_nav ul li")[parseInt(getNewIndex)]) === null || _passEle$querySelecto === void 0 ? void 0 : _passEle$querySelecto.classList.add('active');
			}
			
			setActiveTab(passEle,getOldTabIndex, type);
		}
	
		function setFooterTabData(e,val,passEle,type='') {
	
			let getActiveTab= passEle.querySelector(".mhex_muliti_tab_footer_nav ul li.active");
			let getId= val.getAttribute('id');
			if(getActiveTab.querySelector('a').getAttribute('href') == `#${getId}`) {
				return
			}
	
			getActiveTab.classList.remove('active');
			e.target.parentElement.classList.add('active');
			if(type != 'header-nav') {
				let getNewTabIndex= (e.target).getAttribute("data-index");
				let getnavLi= passEle.querySelectorAll(".mhex_tab_nav_li");
				getnavLi[parseInt(getNewTabIndex)].querySelector('a').click();
			}
			
		}
		
		function setActiveTab( passEle, getOldTabIndex, type="header-nav") {
			if( passEle == null) {
				return false;
			}
			let setType= '';
			let scrollMove= '';
			if(type == 'header-nav') {
				setType= ".mhex_tab_nav_li.active";
	
			}else {
				setType=".mhex_muliti_tab_footer_nav ul li.active";
			}
			
			let getActiveTab= passEle.querySelector(".mhex_tab_nav_li.active");
			let getNewTabIndex= getActiveTab.getAttribute("data-index");
			let animationType= "";
	
			let getActiveEleWidth= getComputedStyle(getActiveTab).width;
			let getParentNav= passEle.querySelector(".mhex_multi_tab_header_nav");
			let headerNavParentWidth= getComputedStyle(getParentNav.parentElement).width;
			getParentNav.setAttribute('data-width', headerNavParentWidth);
			let getNavListWidth= getParentNav.querySelector("ul").scrollWidth;
			
			let getRightPositionValue= getNavListWidth - (getActiveTab.offsetLeft + splitNumber(getActiveEleWidth));
	
			if(parseInt(getOldTabIndex) > parseInt(getNewTabIndex)) {
				passEle.querySelector(".line").setAttribute("style",`right: ${getRightPositionValue}px; left: ${getActiveTab.offsetLeft}px; transition: right 0.6s ease, left 0.63s ease`);
				animationType= 'mhex__tab_content_from_right';
				scrollMove= 'right';
			}else {
				passEle.querySelector(".line").setAttribute("style",`right: ${getRightPositionValue}px; left: ${getActiveTab.offsetLeft}px; transition: left 0.6s ease, right 0.63s ease`);
				animationType= 'mhex__tab_content_from_left';
				scrollMove= 'left';
			}
	
			let checkScroll= isScrollCheck(passEle);
			if ((_checkScroll = checkScroll) !== null && _checkScroll !== void 0 && _checkScroll.scroll) {
				passEle.querySelector(".line").setAttribute("style",`width: ${getActiveEleWidth}; left: ${getActiveTab.offsetLeft}px; transition: all 0.4s ease`); 
				let getNavParent= passEle.querySelector(".mhex_multi_tab_header");
				let getLiWidth= parseFloat(splitNumber(getActiveEleWidth));
				let setScrollWidth= getActiveTab.offsetLeft - ((checkScroll.parentWidth - getLiWidth) / 2);
				let getNextLiWidth= 0;
				let getPrevLiWidth = 0;
				if ((_getActiveTab = getActiveTab) !== null && _getActiveTab !== void 0 && _getActiveTab.nextElementSibling) {
					getNextLiWidth= splitNumber(getComputedStyle(getActiveTab.nextElementSibling).width);
				}
				if ((_getActiveTab = getActiveTab) !== null && _getActiveTab !== void 0 && _getActiveTab.previousElementSibling) {
					getPrevLiWidth= splitNumber(getComputedStyle(getActiveTab.previousElementSibling).width);
				}
	
				let calcLi= 0;
				if(scrollMove == 'left') {
					calcLi= getActiveTab.offsetLeft + getLiWidth + getNextLiWidth;
					if((calcLi > checkScroll.parentWidth) || (getActiveTab.offsetLeft > checkScroll.parentWidth)) {
						$('.mhex_multi_tab_header').animate({
							scrollLeft: setScrollWidth
						},{
							duration: 150,
							easing: "linear"
						});
					}
				}else {
					calcLi= getActiveTab.offsetLeft + getLiWidth + getPrevLiWidth;
					if((calcLi < checkScroll.parentWidth) || (getActiveTab.offsetLeft > setScrollWidth)) {
						$('.mhex_multi_tab_header').animate({
							scrollLeft: setScrollWidth
						},{
							duration: 150,
							easing: "linear"
						});
					}
				}
			}else {
			}
			setTabContentChange(passEle,getActiveTab,animationType);
			
		}
	
	
		function setTabContentChange(passEle,passActiveTab,passAnimationType) {
			
			let getActiveTabContent= passEle.querySelector(".mhex_multi_tab_content.active");
			let getId= passActiveTab.querySelector('a').getAttribute("href");
			let getRightAnimationActive= passEle.querySelector(".mhex__tab_content_from_right");
			let getLeftAnimationActive= passEle.querySelector(".mhex__tab_content_from_left");
			if(getRightAnimationActive) {
				getRightAnimationActive.classList.remove("mhex__tab_content_from_right");
			}
			if(getLeftAnimationActive) {
				getLeftAnimationActive.classList.remove("mhex__tab_content_from_left");
			}
			
			getActiveTabContent.classList.remove('active');
			passEle.querySelector(`${getId}`).classList.add('active',passAnimationType);
		}
	
		function isScrollCheck(passEle) {
			let getParentNav= passEle.querySelector(".mhex_multi_tab_header_nav");
			let getNavListWidth= getParentNav.querySelector("ul").scrollWidth;
			let getParentWidth= splitNumber(getParentNav.getAttribute('data-width'));
			let getActiveNavLi= passEle.querySelector('.mhex_tab_nav_li.active');
			
	
			if(Math.round(parseFloat(getParentWidth)) < getNavListWidth) {
				return {
					scroll: true,
					parentWidth: parseFloat(getParentWidth),
					navWidth: getNavListWidth,
					getActiveNavLi: getActiveNavLi
				};
			}
		}
	
		function splitNumber(passData) {
			let splitNuber= passData.split( "px" );
			return parseFloat(splitNuber);
		}
	
		window.onresize= function(){
			let getControllWrapper= document.querySelectorAll(".mhex_multi_tab_content_wrapper");
			getControllWrapper.forEach((val,index)=>{
				let getActiveTabIndex= val.querySelector('.mhex_tab_nav_li.active');
				setTimeout(()=>{
					setActiveTab(val,getActiveTabIndex.getAttribute('data-index'));
				},400)
			});
		}
		mainController();

	// })(); 

   //integration and devices page tab header script ends//


   // slider starts//
   $('.tab-slider').slick({
	dots: true,
	infinite: false,
	speed: 500,
	slidesToShow: 2,
	slidesToScroll: 1,
	responsive: [
		{
			breakpoint: 1300,
			settings: {
			  slidesToShow: 3,
			  slidesToScroll: 1
			}
		},
		{
			breakpoint: 991,
			settings: {
			  slidesToShow: 2,
			  slidesToScroll: 1
			}
		},		
	  	{
			breakpoint: 600,
			settings: {
			slidesToShow: 1,
			slidesToScroll: 1
			}
	  	},
	]
  });
  

   //slider ends//

   $(".floating-select").change(function(){
		if($(this).val() == "default") {
		$('.floating-select').removeClass('valid');
		} else {
			$('.floating-select').addClass('valid');
		}
	});
	$(".more-cntnt__show-more").removeClass('d-none');
	$(".hex_product_list__left_filter_block__category_block:nth-child(n+6)").addClass('d-none');
	$(".more-cntnt__show-less").addClass('d-none');
	showMore();
	showLess();

	sideMenuClick();


	$('.ripple-button').on('click', rippleAnimation);
  
	/**
	* rippleAnimation
	**/
	function rippleAnimation(e) {
	  //e.preventDefault();
	  $this = $(this);
	  
	  //remove ripple if it's already on
	  $oldRipple = $('.ripple');
	  if($this.has($oldRipple)) $oldRipple.remove();
	  //If your page has more than one button instead of this just do $('.ripple').remove() to remove them all
  
	  //create element
	  $ripple = $(document.createElement('div'));
	  $ripple.addClass('ripple');
  
	  //Get the click's location
	  var eY = e.offsetY;
	  var eX = e.offsetX;
	  
	  //Get the element's width and height
	  var w = $this.width();
	  var h = $this.height();
	  
	  //get the offset of eX and eY
	  var offsetX = Math.abs(w / 2 - eX);
	  var offsetY = Math.abs(h / 2 - eY);
	  
	  //get the delta of X and Y
	  var deltaX = w/2+offsetX;
	  var deltaY = h/2+offsetY;
	  
	  //size
	  //The squareroot of ( deltaX² + deltaY² - 2 * deltaX * deltaY * cos(90°) (in radian = 1/2 PI) ) * 2
	  var size = Math.sqrt( Math.pow(deltaX,2) + Math.pow(deltaY,2) -2 * deltaX * deltaY * Math.cos(Math.PI / 2) ) * 2;
  
	  //apply everything to $ripple
	  $ripple.css({
		'top': eY,
		'left': eX
	  });
	  
	  //and append it
	  $this.append($ripple);
	}
	// Ripple ends







});

function checkListView(){
    if($('.hex_product_list__right_filter_block__grid_list').hasClass('view--inactive')){
        $('.hex_product_list__right_filter_block__grid_list').removeClass('view--inactive');
    }else{
        $('.hex_product_list__right_filter_block__grid_list').addClass('view--inactive');
    }
    if($('.hex_product_list__right_filter_block__normal_list').hasClass('view--inactive')){
        $('.hex_product_list__right_filter_block__normal_list').removeClass('view--inactive');
    }else{
        $('.hex_product_list__right_filter_block__normal_list').addClass('view--inactive');
    }
}

// product list grid view and list view script starts
        
$('.hex_product_list__right_filter_block__normal_list').click(function(){
        $('.product-sec-body').addClass('product-sec--listview');
		$('.product-list-loader').addClass('product-list-view--loader');
        $('.hex_product_list__right_filter_block__grid_list').addClass('view--inactive');
        $('.hex_product_list__right_filter_block__normal_list').removeClass('view--inactive');

})
$('.hex_product_list__right_filter_block__grid_list').click(function(){
        $('.product-sec-body').removeClass('product-sec--listview');
		$('.product-list-loader').removeClass('product-list-view--loader');
        $('.hex_product_list__right_filter_block__grid_list').removeClass('view--inactive');
        $('.hex_product_list__right_filter_block__normal_list').addClass('view--inactive');
})
// produ ct list grid view and list view script ends


// filter list pop up in mobile screens starts//
        
function fliterPopUp(){
    $('.filter-popup').addClass('filter-popup--open');
	$('body').addClass('rmve-bdy--scroll');
}
$(window).on('resize', function(){	
	var win = $(this);	
	if(win.width()>= 992){
		$('.filter-popup').removeClass('filter-popup--open');
		$('body').removeClass('rmve-bdy--scroll');
	}
})
function closeFilter(){
    $('.filter-popup').removeClass('filter-popup--open');
	$('body').removeClass('rmve-bdy--scroll');
}
// filter list pop up in mobile screens ends//


// Enquire modal popup  starts //

function enquireModal(){
	$('.enquire-popup').addClass('enquire-popup--open');
	if($(".coltwo-lft__footer-btn").hasClass("success-popup")){
		$('.enquire-popup').addClass('thank-you--form');
		setTimeout(() => {
			$('.enquire-popup').removeClass('enquire-popup--open');
		}, 5000);
		setTimeout(() => {
			$('.enquire-popup').removeClass('thank-you--form');
		}, 5500);
	}
	else{
		// $('.enquire-popup').addClass('enquire-popup--open');
		$('body').addClass('rmve-scroll');
	}
}

function closeEnquire(){
	$('.enquire-popup').removeClass('enquire-popup--open');
	$('body').removeClass('rmve-scroll');
	
}


// Enquire modal popup  ends//


// remove sortby custom dropdown starts//
$(document).on('click',function(e){
	// console.log('e',e.target);
	if(($(e.target) != $('span'))){
		$('.hex_product_list__select').removeClass('hex_product_list__select--active');
  	}
	if(($(e.target) != $('.home-banner-part-result-block')) && ($(e.target) != $('.no-result-block')) && ($(e.target) != $('.result-loader'))){
		$('.home-banner-part-result-block').removeClass('home-banner-part-result-block--active');
		$('.no-result-block').css("display","none");
		$('.result-loader').css("display","none");
	}
  });
  //remove sortby custom dropdown ends //


  // show more and show less starts //
  		function showMore(){
		  $(".more-cntnt__show-more").click(function(){
			$(".hex_product_list__left_filter_block__category_block:nth-child(n+6)").removeClass('d-none');
			$(".hex_product_list__left_filter_block__category_block:nth-child(n+6)").addClass('d-block');
			$(".more-cntnt__show-more").addClass('d-none');
			$(".more-cntnt__show-less").addClass('d-block');
			$(".more-cntnt__show-less").removeClass('d-none');
		  })
		}

		function showLess(){
			$(".more-cntnt__show-less").click(function(){
				$(".hex_product_list__left_filter_block__category_block:nth-child(n+6)").removeClass('d-block');
				$(".hex_product_list__left_filter_block__category_block:nth-child(n+6)").addClass('d-none');
				$(".more-cntnt__show-more").removeClass('d-none');
				$(".more-cntnt__show-less").addClass('d-none');
				$(".more-cntnt__show-less").removeClass('d-block');

			})
		}
  // show more and show less ends//

  // scroll top based on side menu click starts//

		function sideMenuClick(){
			$('.hex_product_list__left_filter_block__category_block ul li input').click(function(){
				// console.log('hi clicked');
				if($('.product-item-block').length){
					$('html, body').animate({
						scrollTop: $('.product-item-block').offset().top - 200
					},100);
				}
			})
		}


  // scroll top based on side menu click ends//


function changeList(){
	$('#product-result').addClass('move-list-view');
	setTimeout(() => {
	$('#product-result').removeClass('move-list-view');
	}, 200);
}


$('.hex_product_list__right_filter_block__normal_list').click(function(){
	changeList();
});
$('.hex_product_list__right_filter_block__grid_list').click(function(){
	changeList()
});


