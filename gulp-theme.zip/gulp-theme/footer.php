<?php
$jsManifest = file_get_contents(get_template_directory().'/assets/js/rev-manifest.json');
$jsJson = json_decode($jsManifest, true);
?>
<h1>Footer</h1>

<script src="<?php echo get_template_directory_uri(); ?>/assets/dist/js/<?php echo $jsJson['app.min.js'] ?>"></script>
<?php wp_footer(); ?>
	</body>
</html>
