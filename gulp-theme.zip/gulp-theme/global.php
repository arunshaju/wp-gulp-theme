<script defer>
function setcookie_url(cname,cvalue,exdays){
    var d = new Date();
    d.setTime(d.getTime() + (exdays*24*60*60*1000)*30);
    var expires = "expires=" + d.toGMTString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
}
function getcookie_url(cname){
    var name = cname + "=";
    var decodedCookie = decodeURIComponent(document.cookie);
    var ca = decodedCookie.split(';');
    for(var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}
function check_and_store_url(){
    var referrer_url = getcookie_url('referrer_url');
     
    var first_visited_url = getcookie_url('first_visited_url');
    var first_visited_time = getcookie_url('first_visited_time');

    if (!referrer_url){
        var take_referral_url = document.referrer;
        if (!take_referral_url){
             
        }else{
            setcookie_url('referrer_url',take_referral_url,30);
        }
    }
    if(!first_visited_url){
        var take_first_visited_url = window.location.href;
        setcookie_url('first_visited_url',take_first_visited_url,30);
    }
    if (!first_visited_time){
        var current_utc_time = Date.now();
        setcookie_url('first_visited_time',current_utc_time,30);
    }
}
check_and_store_url();

	
function setCookie(cname, cvalue, exdays=15) {
    var d = new Date();
    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000)*30);
    var expires = "expires=" + d.toUTCString();
    document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";

}
function getCookie(name) {
    var nameEQ = name + "=";
    var ca = document.cookie.split(';');
    for(var i=0;i < ca.length;i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1,c.length);
        if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length,c.length);
    }
    return null;
}
function eraseCookie(name) {   
    document.cookie = name +'=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
}
</script>