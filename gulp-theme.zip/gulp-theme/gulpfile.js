'use strict';
const gulp = require('gulp');
const sass = require('gulp-sass')(require('sass'));
const prefix = require('gulp-autoprefixer');
const minify = require('gulp-clean-css');
const terser = require('gulp-terser');
const concat = require('gulp-concat');
const RevAll = require('gulp-rev-all');
var gulpif = require('gulp-if');
var clean = require('gulp-clean');
var cssUrlReplace = require('gulp-css-url-replace');
var minimist = require('minimist');
var sourcemaps = require('gulp-sourcemaps');
const imagemin = require('gulp-imagemin');
var webp = require("gulp-webp");
const imageminWebp = require("imagemin-webp");

//compile, prefix, and min scss
gulp.task('compilescss',async function(){
  var knownOptions = {
    string: 'env',
    default: { env: process.env.NODE_ENV || 'development' }
  };
  var options = minimist(process.argv.slice(2), knownOptions);
  if(options.bucketurl){
    var bucketUrl = options.bucketurl+'/dist/images/'
  } else {
    var bucketUrl = '../images/';
  }
  
  gulp.src('assets/scss/main.scss')
      .pipe(gulpif(options.env === 'development', sourcemaps.init()))
      .pipe(sass().on('error', sass.logError))
      .pipe(prefix('last 2 versions'))
      .pipe(cssUrlReplace({ img:bucketUrl}))
      .pipe(minify())
      .pipe(concat('style.min.css'))
      .pipe(gulpif(options.env === 'development', sourcemaps.write('.')))
      .pipe(gulp.dest("assets/dist/css"))
      .pipe(RevAll.revision())
      .pipe(gulp.dest("assets/dist/css"))
      .pipe(RevAll.manifestFile())
      .pipe(gulp.dest("assets/css"));
})

// minify js
gulp.task('jsmin',async function(){
  var knownOptions = {
    string: 'env',
    default: { env: process.env.NODE_ENV || 'development' }
  };
  var options = minimist(process.argv.slice(2), knownOptions);
  
  gulp.src([
    './assets/js/app.js'
    ])
      .pipe(gulpif(options.env === 'development', sourcemaps.init()))
      .pipe(terser())
      .pipe(concat('app.min.js'))
      .pipe(gulpif(options.env === 'development', sourcemaps.write('.')))
      .pipe(gulp.dest("assets/dist/js"))
      .pipe(RevAll.revision())
      .pipe(gulp.dest("assets/dist/js"))
      .pipe(RevAll.manifestFile())
      .pipe(gulp.dest("assets/js"));
})

// gulp.task('imagemin', async function(){
//   gulp.src(["assets/images/*"])
//   .pipe(imagemin())
//   .pipe(gulp.dest('assets/dist/images'))
// });

gulp.task("imagemin", function() {
  const stream = gulp
    .src(['assets/images/*'])
    .pipe(imagemin({
        verbose: true,
        plugins: webp({ quality: 70 })
      })
    )
    .pipe(gulp.dest("assets/dist/images"));
    return stream;
});

gulp.task("imagecp",async function() {
  gulp
    .src(['assets/images/*'])
    .pipe(gulp.dest("assets/dist/images"));
});
// gulp.task('webp', async function(){
//   gulp.src(["assets/images/*.png","assets/images/*.jpg"])
//   .pipe(webp())
//   .pipe(gulp.dest('assets/dist/images/webp'))
// });

function debug() {
  var knownOptions = {
    string: 'env',
    default: { env: process.env.NODE_ENV || 'production' }
  };
  var options = minimist(process.argv.slice(2), knownOptions);
  console.log ("bucketurl", options.bucketurl);
  return options.env;
}

gulp.task("log", async function () {
  gulp.
  pipe(debug());
});

gulp.task('clean', function(){
  return gulp.src('assets/dist', {read: false, allowEmpty: true})
  .pipe(clean());
});

//watch task for development purpose
gulp.task('watch', function(){
  gulp.watch('assets/scss/**/*.scss', gulp.series('clean','compilescss','jsmin','imagecp'));
  gulp.watch('assets/js/*.js', gulp.series('clean','compilescss','jsmin','imagecp'));
});

//build assets for devops only
gulp.task('default', gulp.series('clean','compilescss','jsmin','imagemin'));