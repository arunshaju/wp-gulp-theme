<?php
$cssManifest = file_get_contents(get_template_directory().'/assets/css/rev-manifest.json');
$cssJson = json_decode($cssManifest, true);
?>
<!DOCTYPE html> 
<html class="no-js">
	<head>
		<!--meta rules-->
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" id="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no, minimal-ui, viewport-fit=cover">
		<meta name="format-detection" content="telephone=no">
		<meta name="HandheldFriendly" content="true">
		<meta http-equiv="x-rim-auto-match" content="none">
		<meta http-equiv="ScreenOrientation" content="autoRotate:disabled">
		<meta name="application-name" content="Tarus">
		<link rel="stylesheet" href="<?php echo get_template_directory_uri(); ?>/assets/dist/css/<?php echo $cssJson['style.min.css'] ?>">
		<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
		<?php wp_head(); ?>
	</head>

	<body>
    <h1>Header</Header></h1>