<?php 
/*Template Name: Home page*/
get_header();
?>
<h1>Home</h1>
<?php get_footer(); ?>