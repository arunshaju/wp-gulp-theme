<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form id="myForm">
        <input type="text" id="name">
        <input type="email" id="email">
        <button type="button" value="send an email">Submit</button>
    </form>
    <p class="sent-notification"></p>
    <script
  src="https://code.jquery.com/jquery-3.6.0.min.js"
  integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4="
  crossorigin="anonymous"></script>
  <script type="text/javascript">
    $(document).ready(function(){
        $("button").click(function(){
            alert(1);
            var name = $("#name");
            var email = $("#email");

            if(isNotEmpty(name) && isNotEmpty(email)){
                $.ajax({
                    url: 'sendEmail.php',
                    method: 'POST',
                    dataType: 'json',
                    data:{
                        name: name.val(),
                        email: email.val()
                    }
                });
                $('#myForm')[0].reset();
                $('.sent-notification').text("Message sent seccessfully");
            }
        });
        function isNotEmpty(caller){
            if(caller.val()==""){
                caller.css('border','1px solid red');
                return false;
            }
            else{
                caller.css('border','');
                return true;
            }
        }
        
    });
  </script>
</body>
</html>